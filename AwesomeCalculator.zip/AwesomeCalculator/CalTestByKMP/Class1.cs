﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AwesomeCalculator;
using NUnit.Framework;

namespace CalTestByKMP
{
    public class Class1
    {
        [TestFixture]
        class CalcTests
        {
            [Test]
            public void GetDivision_Input10and5_Returns9point0()
            {
                //Arrange 
                double number1 = 10;
                double number2 = 5;

                double expectedResult = number1 / number2;

                Calc testCalc = new Calc(number1, number2);

                //Act 
                double actualResult = testCalc.GetDivision();
                //Assert 
                Assert.AreEqual(expectedResult, actualResult);
            }

            [Test]
            public void GetMultiplication_Input10and5_Returns9point0()
            {
                //Arrange 
                double number1 = 10;
                double number2 = 5;

                double expectedResult = number1 * number2;

                Calc testCalc = new Calc(number1, number2);

                //Act 
                double actualResult = testCalc.GetMultiplication();
                //Assert 
                Assert.AreEqual(expectedResult, actualResult);
            }
            [Test]
            public void GetAddition_Input10and5_Returns9point0()
            {
                //Arrange 
                double number1 = 10;
                double number2 = 5;

                double expectedResult = number1 + number2;

                Calc testCalc = new Calc(number1, number2);

                //Act 
                double actualResult = testCalc.GetAddition();
                //Assert 
                Assert.AreEqual(expectedResult, actualResult);
            }
            [Test]
            public void GetSubtraction_Input10and5_Returns9point0()
            {
                //Arrange 
                double number1 = 10;
                double number2 = 5;

                double expectedResult = number1 - number2;

                Calc testCalc = new Calc(number1, number2);

                //Act 
                double actualResult = testCalc.GetSubtraction();
                //Assert 
                Assert.AreEqual(expectedResult, actualResult);
            }
            [Test]
            public void GetDivision_Input100and7_Returns9point0()
            {
                //Arrange 
                double number1 = 100;
                double number2 = 2;

                double expectedResult = number1 / number2;

                Calc testCalc = new Calc(number1, number2);

                //Act 
                double actualResult = testCalc.GetDivision();
                //Assert 
                Assert.AreEqual(expectedResult, actualResult);
            }

            [Test]
            public void GetMultiplication_Input9and13_Returns9point0()
            {
                //Arrange 
                double number1 = 9;
                double number2 = 13;

                double expectedResult = number1 * number2;

                Calc testCalc = new Calc(number1, number2);

                //Act 
                double actualResult = testCalc.GetMultiplication();
                //Assert 
                Assert.AreEqual(expectedResult, actualResult);
            }
            [Test]
            public void GetAddition_Input113and225_Returns33()
            {
                //Arrange 
                double number1 = 113;
                double number2 = 225;

                double expectedResult = number1 + number2;

                Calc testCalc = new Calc(number1, number2);

                //Act 
                double actualResult = testCalc.GetAddition();
                //Assert 
                Assert.AreEqual(expectedResult, actualResult);
            }
            [Test]
            public void GetSubtraction_Input97and39_Returns9point0()
            {
                //Arrange 
                double number1 = 97;
                double number2 = 39;

                double expectedResult = number1 - number2;

                Calc testCalc = new Calc(number1, number2);

                //Act 
                double actualResult = testCalc.GetSubtraction();
                //Assert 
                Assert.AreEqual(expectedResult, actualResult);
            }
            [Test]
            public void GetDivision_Input28and4_Returns9point0()
            {
                //Arrange 
                double number1 = 28;
                double number2 = 4;

                double expectedResult = number1 / number2;

                Calc testCalc = new Calc(number1, number2);

                //Act 
                double actualResult = testCalc.GetDivision();
                //Assert 
                Assert.AreEqual(expectedResult, actualResult);
            }

            [Test]
            public void GetMultiplication_Input100and1_Returns100()
            {
                //Arrange 
                double number1 = 100;
                double number2 = 1;

                double expectedResult = number1 * number2;

                Calc testCalc = new Calc(number1, number2);

                //Act 
                double actualResult = testCalc.GetMultiplication();
                //Assert 
                Assert.AreEqual(expectedResult, actualResult);
            }
            [Test]
            public void GetAddition_Input22and26_Returns9point0()
            {
                //Arrange 
                double number1 = 22;
                double number2 = 26;

                double expectedResult = number1 + number2;

                Calc testCalc = new Calc(number1, number2);

                //Act 
                double actualResult = testCalc.GetAddition();
                //Assert 
                Assert.AreEqual(expectedResult, actualResult);
            }
            [Test]
            public void GetSubtraction_Input11and7_Returns9point0()
            {
                //Arrange 
                double number1 = 11;
                double number2 = 7;

                double expectedResult = number1 - number2;

                Calc testCalc = new Calc(number1, number2);

                //Act 
                double actualResult = testCalc.GetSubtraction();
                //Assert 
                Assert.AreEqual(expectedResult, actualResult);
            }

        }

    }       
}
